<template>
#[[$END$]]#
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component({
name: "${COMPONENT_NAME}"
})
export default class ${COMPONENT_NAME} extends Vue {

}
</script>

<style lang="scss" scoped>

</style>